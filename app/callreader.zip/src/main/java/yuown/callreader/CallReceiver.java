package yuown.callreader;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import java.util.Locale;

/**
 * Created by kirannk on 05/10/16.
 */
public class CallReceiver extends BroadcastReceiver {

    private static final String TAG = "CallReader";

    private static boolean incomingFlag = false;

    private static String incoming_number = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);
        Intent t = new Intent();
        switch (tm.getCallState()) {
            case TelephonyManager.CALL_STATE_RINGING:
                incomingFlag = true;
                incoming_number = intent.getStringExtra("incoming_number");

                t.setClass(context, TTS.class);
                t.putExtra("toSpeak", incoming_number);
                t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |  Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS|Intent.FLAG_ACTIVITY_NO_HISTORY);
                context.startActivity(t);


                Log.i(TAG, "RINGING :" + incoming_number);
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                if (incomingFlag) {
                    Log.i(TAG, "incoming ACCEPT :" + incoming_number);
                    TTS.ttsAct.finish();
                }
                break;
            case TelephonyManager.CALL_STATE_IDLE:
                if (incomingFlag) {
                    Log.i(TAG, "incoming IDLE");
                    TTS.ttsAct.finish();
                }
                break;
        }
    }
}